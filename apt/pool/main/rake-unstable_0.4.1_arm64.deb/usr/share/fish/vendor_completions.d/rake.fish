# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rake_global_optspecs
	string join \n f/file= dry-run h/help V/version
end

function __fish_rake_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_rake_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_rake_using_subcommand
	set -l cmd (__fish_rake_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c rake -n "__fish_rake_needs_command" -s f -l file -d 'Path to the Rakefile' -r -F
complete -c rake -n "__fish_rake_needs_command" -l dry-run -d 'Print the targets and commands that would run without executing anything. Tool checks and toolchain operations are also skipped. Configuration errors (unknown targets, missing shell variants) are still reported'
complete -c rake -n "__fish_rake_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rake -n "__fish_rake_needs_command" -s V -l version -d 'Print version'
complete -c rake -n "__fish_rake_needs_command" -f -a "list" -d 'List the available targets and their commands'
complete -c rake -n "__fish_rake_needs_command" -f -a "syntax" -d 'Parse and validate the Rakefile, reporting any errors'
complete -c rake -n "__fish_rake_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rake -n "__fish_rake_using_subcommand list" -s f -l file -d 'Path to the Rakefile' -r -F
complete -c rake -n "__fish_rake_using_subcommand list" -l dry-run -d 'Print the targets and commands that would run without executing anything. Tool checks and toolchain operations are also skipped. Configuration errors (unknown targets, missing shell variants) are still reported'
complete -c rake -n "__fish_rake_using_subcommand list" -s h -l help -d 'Print help'
complete -c rake -n "__fish_rake_using_subcommand syntax" -s f -l file -d 'Path to the Rakefile' -r -F
complete -c rake -n "__fish_rake_using_subcommand syntax" -l dry-run -d 'Print the targets and commands that would run without executing anything. Tool checks and toolchain operations are also skipped. Configuration errors (unknown targets, missing shell variants) are still reported'
complete -c rake -n "__fish_rake_using_subcommand syntax" -s h -l help -d 'Print help'
complete -c rake -n "__fish_rake_using_subcommand help; and not __fish_seen_subcommand_from list syntax help" -f -a "list" -d 'List the available targets and their commands'
complete -c rake -n "__fish_rake_using_subcommand help; and not __fish_seen_subcommand_from list syntax help" -f -a "syntax" -d 'Parse and validate the Rakefile, reporting any errors'
complete -c rake -n "__fish_rake_using_subcommand help; and not __fish_seen_subcommand_from list syntax help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
