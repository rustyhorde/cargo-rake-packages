complete -c rake -s f -l file -d 'Path to the Rakefile' -r -F
complete -c rake -s l -l list -d 'List the available targets instead of running one'
complete -c rake -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rake -s V -l version -d 'Print version'
